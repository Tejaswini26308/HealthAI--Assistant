
import streamlit as st
import requests

API_KEY = "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"
API_URL = "https://api-inference.huggingface.co/models/ibm-granite/granite-13b-chat"

def generate_response(prompt):
    headers = {"Authorization": f"Bearer {API_KEY}"}
    payload = {"inputs": prompt, "parameters": {"max_new_tokens": 300}}
    response = requests.post(API_URL, headers=headers, json=payload)
    if response.status_code == 200:
        return response.json()[0]["generated_text"].replace(prompt, "").strip()
    return "❌ Error: Model not responding."

def answer_question(q):
    prompt = f"""As a healthcare AI, answer this simply and kindly:

PATIENT: {q}

Guidelines:
- Use easy words
- Don’t diagnose
- Suggest doctor if needed

RESPONSE:"""
    return generate_response(prompt)

def predict_condition(symptoms, age, gender, history):
    prompt = f"""Predict 3 likely conditions:

Symptoms: {symptoms}
Age: {age}, Gender: {gender}
History: {history}

Include:
1. Name
2. Likelihood
3. Reason
4. Next Step

RESPONSE:"""
    return generate_response(prompt)

def get_treatment_plan(cond, age, gender, history):
    prompt = f"""Create treatment plan:

Condition: {cond}
Age: {age}, Gender: {gender}
History: {history}

Include: medicine, diet, lifestyle, testing

RESPONSE:"""
    return generate_response(prompt)

# 🎨 Streamlit UI
st.set_page_config(page_title="HealthAI")
st.title("🩺 HealthAI – Chat Assistant")

opt = st.sidebar.radio("Choose Feature", ["💬 Ask Question", "🔍 Predict Condition", "📋 Treatment Plan"])

if opt == "💬 Ask Question":
    q = st.text_area("Enter your question:")
    if st.button("Answer"):
        st.success(answer_question(q))

elif opt == "🔍 Predict Condition":
    s = st.text_input("Symptoms:")
    a = st.number_input("Age", 0, 120, 25)
    g = st.selectbox("Gender", ["Male", "Female", "Other"])
    h = st.text_input("Medical History:")
    if st.button("Predict"):
        st.info(predict_condition(s, a, g, h))

elif opt == "📋 Treatment Plan":
    c = st.text_input("Condition (e.g., Diabetes):")
    a = st.number_input("Age", 0, 120, 30)
    g = st.selectbox("Gender", ["Male", "Female", "Other"])
    h = st.text_input("Medical History:")
    if st.button("Get Plan"):
        st.success(get_treatment_plan(c, a, g, h))

# 💖 Footer
st.markdown("---")
st.markdown("<h5 style='text-align: center;'>🛠️ Built by 💖 <b>Bangaru Tejaswini</b><br>🩺 Sample for Internship Project ✨</h5>", unsafe_allow_html=True)
